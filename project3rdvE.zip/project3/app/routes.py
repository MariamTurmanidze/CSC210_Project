import sqlite3
from io import BytesIO

import pyqrcode as pyqrcode
from flask import render_template, flash, redirect, url_for, request, session, abort
from flask_login import login_user, logout_user, current_user, login_required
from app import app, db, bcrypt
from app.forms import LoginForm, RegistrationForm, TimeEntryForm, EditProfileForm
from app.models import User, Time_Entry, Paycheck


@app.route("/")
def index(): 
    if current_user.is_authenticated:
	    return render_template("employee_main.html")
    else:
        return render_template("index.html")


@app.route("/register", methods = ['POST', 'GET'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    form = RegistrationForm()
    if form.validate_on_submit():
        # hash passwords from the reistration form using bcrypt as a string (utf-8) instead of bytes
        hashed_pwd = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
        # creating a new instance of user and passing all the fields from the form and hashed pwd
        user = User(employee_id=form.employee_id.data,lname=form.lname.data, fname=form.fname.data,
                    ssn=form.ssn.data, email=form.email.data, address=form.address.data,
                    dep_name=form.dep_name.data, password=hashed_pwd)
        # add user to the database
        db.session.add(user)
        db.session.commit()
        flash('Congratulations, you are now a registered employee!')

        session['employee_id'] = user.employee_id
        return redirect(url_for('two_factor_setup'))
        #return redirect(url_for('success'))

    return render_template('register.html', title='Register', form=RegistrationForm())

   
@app.route('/login', methods=['GET', 'POST'])
def login():
        if current_user.is_authenticated:
           return redirect(url_for('employee_main'))
        form = LoginForm()
        if form.validate_on_submit():
           user = User.query.filter_by(employee_id=form.employee_id.data).first()
           if user and bcrypt.check_password_hash(user.password, form.password.data) and user.verify_totp(form.token.data):
                   login_user(user, remember=form.remember_me.data)
                   return render_template('employee_main.html', title='Home', employee_id=form.employee_id.data)
           else:
                   flash('Failed Login. Incorrect Employee ID or Password')
        return render_template('login.html', title='Sign In', form=form)
    

@app.route("/time_entry/int<employee_id>", methods = ['POST', 'GET'])
def time_entry(employee_id):
    form = TimeEntryForm()
    user = User.query.get_or_404(employee_id)
    if form.validate_on_submit():
        entry = Time_Entry(time_in=form.time_in.data, time_out=form.time_out.data, request_id=user.employee_id)
        db.session.add(entry)
        db.session.commit()
        flash('Your time entry has been recorded')
        return redirect(url_for('entrysuccess'))
    return render_template('time_entry.html', title='Time Entry', form=TimeEntryForm())

@app.route('/edit/int<employee_id>', methods = ['POST', 'GET'])
def edit(employee_id):
    form = EditProfileForm()
    user_to_update = User.query.get_or_404(employee_id)
    form.employee_id.data = current_user.employee_id
    form.lname.data = current_user.lname
    form.fname.data = current_user.fname
    form.email.data = current_user.email
    form.ssn.data = current_user.ssn
    form.address.data = current_user.address
    form.dep_name.data = current_user.dep_name
	
    if request.method == "POST":
        user_to_update.employee_id = request.form['employee_id']
        user_to_update.lname = request.form['lname']
        user_to_update.fname = request.form['fname']
        user_to_update.email = request.form['email']
        user_to_update.ssn = request.form['ssn']
        user_to_update.address = request.form['address']
        user_to_update.dep_name = request.form['dep_name']
        db.session.commit()
        flash("Employee Information Updated Successfully!")
        return redirect(url_for('editsuccess'))
    return render_template("edit.html",
                            form=form, user_to_update = user_to_update,
                            employee_id=employee_id)

@app.route("/home")
def employee_main():
    return render_template('employee_main.html', title='Home Page')


@app.route("/view_entries/int<employee_id>")
def view_entries(employee_id):
    user = User.query.get_or_404(employee_id)
    entries = user.entries
    return render_template('view_entries.html', title='Previous Entries',
                           user=user, entries=entries)


@app.route("/view_paycheck")
def view_paycheck():
    if Paycheck.query.filter_by(Employee_ID=current_user.employee_id).all() is None:
        flash('No previous paychecks submitted')
        return render_template('view_paycheck.html', title='Paycheck')
    else:
        paycheck = Paycheck.query.filter_by(Employee_ID=current_user.employee_id).all()
        return render_template('view_paycheck.html', title='Paycheck', rows=paycheck)


@app.route('/twofactor')
def two_factor_setup():
    if 'employee_id' not in session:
        return redirect(url_for('index'))
    user = User.query.filter_by(employee_id=session['employee_id']).first()
    if user is None:
        return redirect(url_for('index'))
    # since this page contains the sensitive qrcode, make sure the browser
    # does not cache it
    return render_template('two-factor-setup.html'), 200, {
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0'}

@app.route('/qrcode')
def qrcode():
    if 'employee_id' not in session:
        abort(404)
    user = User.query.filter_by(employee_id=session['employee_id']).first()
    if user is None:
        abort(404)

    # for added security, remove username from session
    del session['employee_id']

    # render qrcode for FreeTOTP
    url = pyqrcode.create(user.get_totp_uri())
    stream = BytesIO()
    url.svg(stream, scale=3)
    return stream.getvalue(), 200, {
        'Content-Type': 'image/svg+xml',
        'Cache-Control': 'no-cache, no-store, must-revalidate',
        'Pragma': 'no-cache',
        'Expires': '0'}

@app.route("/profile")
def profile():
    return render_template('profile.html', title='Profile')

@app.route("/success")
def success():
    return render_template('success.html', title='Registration Successful')

@app.route("/entrysuccess")
def entrysuccess():
    return render_template('entrysuccess.html', title='Entry Successful')

@app.route("/editsuccess")
def editsuccess():
    return render_template('editsuccess.html', title='Edit Successful')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.')
    return redirect(url_for('index'))


@app.route("/secret")
@login_required
def secret():
  return "Only authenticated users are allowed!"
