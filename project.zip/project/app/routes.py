##from flask import Flask, render_template, request
##
##from flask import Flask
##from flask import render_template, request, redirect, url_for
##from flask import abort
##import json
##
##from flask_wtf import FlaskForm
##from flask_sqlalchemy import SQLAlchemy
##from wtforms import StringField, PasswordField, BooleanField, SubmitField, DateField
##import email_validator
##from wtforms.validators import DataRequired, Length, Email, EqualTo
##from flask_login import LoginManager, UserMixin, login_required, logout_user, current_user
##import os
##from werkzeug.security import generate_password_hash, check_password_hash
##from forms import LoginForm, RegistrationForm
##from models import User


##app = Flask(__name__)
##SECRET_KEY = os.urandom(32)
##app.config['SECRET_KEY'] = SECRET_KEY
##app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:////tmp/test.db'
##db = SQLAlchemy(app)
##login_manager = LoginManager()
##login_manager.init_app(app)
##login_manager.login_view = 'login'



# CLASSES

##class LoginForm(FlaskForm):
##  employee_id = StringField('Employee ID', validators=[DataRequired()])
##  email = StringField("Email", validators = [DataRequired(), \
##                                              Length(1, 64), Email()])
##  password = PasswordField("Password", validators = [DataRequired()])
##  remember_me = BooleanField("Keep me logged in")
##  submit = SubmitField("Log In")
##
##  def validate_id(self, employee_id):
##    conn = sqlite3.connect('/employees.db')
##    curs = conn.cursor()
##    curs.execute("SELECT employee_id FROM employees where employee_id = (?)",[employee_id.data])
##    validid = curs.fetchone()
##    if validid is None:
##      raise ValidationError('This Employee ID is not registered. Please register before login')
##
##
##class RegistrationForm(FlaskForm):
##    employee_id = StringField('Employee_ID', validators=[DataRequired()])
##    lname = StringField('Last Name', validators=[DataRequired()])
##    fname = StringField('First Name', validators=[DataRequired()])
##    ssn = StringField('SSN', validators=[DataRequired()])
##    email = StringField('Email', validators=[DataRequired(), Email()])
##    address = StringField('address', validators=[DataRequired()])
##    dep_name = StringField('Department Name', validators=[DataRequired()])
##    password = PasswordField('Password', validators=[DataRequired()])
##    password2 = PasswordField(
##        'Repeat Password', validators=[DataRequired(), EqualTo('password')])
##    submit = SubmitField('Register')
##
##    def validate_username(self, username):
##        user = User.query.filter_by(username=username.data).first()
##        if user is not None:
##            raise ValidationError('Please use a different username.')
##
##    def validate_email(self, email):
##        user = User.query.filter_by(email=email.data).first()
##        if user is not None:
##            raise ValidationError('Please use a different email address.')
##

# ROUTES


import sqlite3
from flask import render_template, flash, redirect, url_for, request
from flask_login import login_user, logout_user, current_user, login_required
from werkzeug.urls import url_parse
from app import app, db, bcrypt
from app.forms import LoginForm, RegistrationForm
from app.models import User


@app.route("/")
def index(): 
	return render_template("index.html")


@app.route("/register", methods = ['POST', 'GET'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    form = RegistrationForm()
    if form.validate_on_submit():
        hashed_pwd = bcrypt.generate_password_hash(form.password.data).decide('utf-8')
        user = User(employee_id=form.employee_id.data, password=hashed_pwd)
        db.session.add(user)
        db.session.commit()
        flash('Congratulations, you are now a registered employee!')
        return redirect(url_for('login'))
    return render_template('register.html', title='Register', form=RegistrationForm())


##@app.route("/registeremployee", methods = ['POST', 'GET'])
##def registeremployee():
##	if request.method == "POST":
##		employee_id = request.form["employee_id"]
##		lname = request.form["lname"]
##		fname = request.form["fname"]
##		ssn = request.form["ssn"]
##		email = request.form["email"]
##		address = request.form["address"]
##		dep_name = request.form["dep_name"]
##		hashPwd = request.form["password"]
##
##	with sqlite3.connect("employees.db") as con:
##		cur = con.cursor()
##		cur.execute("INSERT into employees (employee_id, lname, fname, ssn, email, \
##address, dep_name) values (?,?,?,?,?,?,?)", (employee_id, lname, fname, ssn, email, \
##address, dep_name))
##		cur.execute("INSERT into loginAuth (employee_id, HashPwd) values (?,?)", (employee_id, hashPwd))
##		con.commit()
##	msg = "Registration was successfull. Welcome to MMZ!"
##	return render_template("success.html", msg = msg)
##	con.close()
    

@app.route('/login', methods=['GET', 'POST'])
def login():
        if current_user.is_authenticated:
           return redirect(url_for('index'))
        form = LoginForm()
        if form.validate_on_submit():
           user = User.query.filter_by(employee_id=form.employee_id.data).first()
           if user is None or not user.check_password(form.password.data):
               flash('Invalid username or password')
               return redirect(url_for('login'))
           login_user(user, remember=form.remember_me.data)
           next_page = request.args.get('next')
           if not next_page or url_parse(next_page).netloc != '':
               next_page = url_for('index')
           return redirect(next_page)
        return render_template('login.html', title='Sign In', form=form)
    


@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.')
    return redirect(url_for('index'))

@app.route("/secret")
@login_required
def secret():
  return "Only authenticated users are allowed!"



        
