import sqlite3
from flask import render_template, flash, redirect, url_for, request
from flask_login import login_user, logout_user, current_user, login_required
from app import app, db, bcrypt
from app.forms import LoginForm, RegistrationForm, TimeEntryForm
from app.models import User, Time_Entry


@app.route("/")
def index(): 
    if current_user.is_authenticated:
	    return render_template("employee_main.html")
    else:
        return render_template("index.html")


@app.route("/register", methods = ['POST', 'GET'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    form = RegistrationForm()
    if form.validate_on_submit():
        # hash passwords from the reistration form using bcrypt as a string (utf-8) instead of bytes
        hashed_pwd = bcrypt.generate_password_hash(form.password.data).decode('utf-8')
        # creating a new instance of user and passing all the fields from the form and hashed pwd
        user = User(employee_id=form.employee_id.data,lname=form.lname.data, fname=form.fname.data,
                    ssn=form.ssn.data, email=form.email.data, address=form.address.data,
                    dep_name=form.dep_name.data, password=hashed_pwd)
        # add user to the database
        db.session.add(user)
        db.session.commit()
        flash('Congratulations, you are now a registered employee!')
        return redirect(url_for('success'))
    return render_template('register.html', title='Register', form=RegistrationForm())

   
@app.route('/login', methods=['GET', 'POST'])
def login():
        if current_user.is_authenticated:
           return redirect(url_for('employee_main'))
        form = LoginForm()
        if form.validate_on_submit():
           user = User.query.filter_by(employee_id=form.employee_id.data).first()
           if user and bcrypt.check_password_hash(user.password, form.password.data):
                   login_user(user, remember=form.remember_me.data)
                   return render_template('employee_main.html', title='Home', employee_id=form.employee_id.data)
           else:
                   flash('Failed Login. Incorrect Employee ID or Password')
        return render_template('login.html', title='Sign In', form=form)
    

@app.route("/time_entry", methods = ['POST', 'GET'])
def time_entry():
    form = TimeEntryForm()
    if form.validate_on_submit():
        session(current_user.employee_id.data)
        entry = Time_Entry(employee_id=current_user.employee_id.data,time_in=form.time_in.data, time_out=form.time_out.data)
        db.session.add(entry)
        db.session.commit()
        flash('Your time entry has been recorded')
        return redirect(url_for('entrysuccess'))
    return render_template('time_entry.html', title='Time Entry', form=TimeEntryForm())


@app.route("/home")
def employee_main():
    return render_template('employee_main.html', title='Home Page')


@app.route("/view_entries")
def view_entries():
	return render_template('view_entries.html', title='Previous Entries')


@app.route("/view_paycheck")
def view_paycheck():
    return render_template('view_paycheck.html', title='Paycheck')


@app.route("/profile")
def profile():
    return render_template('profile.html', title='Profile')


@app.route("/success")
def success():
    return render_template('success.html', title='Registration Successful')

@app.route("/entrysuccess")
def entrysuccess():
    return render_template('entrysuccess.html', title='Entry Successful')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    flash('You have been logged out.')
    return redirect(url_for('index'))


@app.route("/secret")
@login_required
def secret():
  return "Only authenticated users are allowed!"
