import datetime

from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from flask_migrate import Migrate
from flask_login import LoginManager
from config import Config
from flask_bcrypt import Bcrypt
import csv



app = Flask(__name__)
app.config['SECRET_KEY'] = 'whatever'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:////app/employees.db'
app.config.from_object(Config)
db = SQLAlchemy(app)
migrate = Migrate(app, db)
login_manager = LoginManager(app)
login_manager.login_view = 'login'
bcrypt = Bcrypt(app)

from app import routes, models

@app.before_first_request
def create_tables():
    db.create_all()
    with open('employees.csv') as csv_file:
            csv_reader = csv.reader(csv_file, delimiter=',')
            line_count = 0
            for row in csv_reader:
                if line_count == 0:
                    pass
                else:
                    hashed_pwd = bcrypt.generate_password_hash(row[8]).decode('utf-8')
                    user = models.User(employee_id=row[0], lname=row[1], fname=row[2],
                                ssn=row[3], email=row[4], address=row[5],
                                dep_name=row[7], password=hashed_pwd)
                    # add user to the database
                    if models.User.query.filter_by(employee_id=row[0]).first() is None:
                        db.session.add(user)
                        db.session.commit()
                    else:
                        pass


                line_count += 1

    with open('PastPaychecks.csv') as csv_file:
            csv_reader = csv.reader(csv_file, delimiter=',')
            line_count = 0
            for row in csv_reader:
                if line_count == 0:
                    pass
                else:
                    paycheck = models.Paycheck(Paycheck_ID=row[0], Employee_ID=row[1],
                                        Start_Date=datetime.datetime.strptime(row[2], '%m/%d/%Y').date(),
                                        End_date=datetime.datetime.strptime(row[3], '%m/%d/%Y').date(), TimeElapsed=row[4],
                                        HourlyWage=row[5], TotalPay=row[6])

                    if models.Paycheck.query.filter_by(Paycheck_ID=row[0]).first() is None:
                        db.session.add(paycheck)
                        db.session.commit()
                    else:
                        pass

                line_count += 1


