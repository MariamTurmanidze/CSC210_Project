from flask import Flask, render_template, request
import sqlite3


app = Flask(__name__)


@app.route("/")
def index(): 
	return render_template("index.html")

@app.route("/add")
def add(): 
	return render_template("add.html")

@app.route("/sell")
def sell(): 
	return render_template("sell.html")


@app.route("/savedetails", methods = ['POST', 'GET'])
def saveDetails():
	msg = "msg"
	if request.method == "POST":
		name = request.form["name"]
		manf = request.form["manf"]
		available = request.form["available"]
	with sqlite3.connect("beers.db") as con:
		cur = con.cursor()
		cur.execute("INSERT into Beers (name, manf, available) values (?,?,?)", (name, manf, available))
		con.commit()
	msg = "Beer successfully added"
	return render_template("success.html", msg = msg)
	con.close()


@app.route("/view")
def view():
	con = sqlite3.connect("beers.db")
	con.row_factory = sqlite3.Row
	cur = con.cursor()
	cur.execute("select * from Beers")
	rows = cur.fetchall()
	return render_template("view.html", rows = rows)


@app.route("/savedetails2", methods = ['POST', 'GET'])
def saveDetails2():
	msg = "msg"
	if request.method == "POST":
		beername = request.form["beername"]
		quantity = request.form["quantity"]
	with sqlite3.connect("sales.db") as con:
		cur = con.cursor()
		cur.execute("INSERT into Sales (beername, quantity) values (?,?)", (beername, quantity))
		con.commit()
	msg = "Sale successfully added"
	return render_template("success.html", msg = msg)
	con.close()


@app.route("/show")
def show():
	con = sqlite3.connect("sales.db")
	con.row_factory = sqlite3.Row
	cur = con.cursor()
	cur.execute("select * from Sales")
	rows = cur.fetchall()
	return render_template("show.html", rows = rows)
