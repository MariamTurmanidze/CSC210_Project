import sqlite3

con = sqlite3.connect('employees.db')
con = sqlite3.connect('timeEntry.db')
con = sqlite3.connect('paychecks.db')
con = sqlite3.connect('manager.db')
con = sqlite3.connect('loginAuth.db')

print("Database opened successfully")

con.execute("create table Employees (Username CHAR PRIMARY KEY, Lname CHAR(20), \
Fname CHAR(20), SSN INTEGER, Email EMAIL, \
Address CHAR(100), Is_Manager BOOLEAN, Dep_Name CHAR(20))")
print("Employee Table created successfully")


con.close()
