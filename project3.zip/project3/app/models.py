from datetime import datetime, timedelta
from app import db, login_manager
from flask_login import UserMixin
from werkzeug.security import generate_password_hash, check_password_hash


class User(db.Model, UserMixin):
  __tablename__ = 'User'
  employee_id = db.Column(db.Integer, primary_key=True)
  lname = db.Column(db.String(60), index=False, nullable=False)
  fname = db.Column(db.String(60), index=False, nullable=False)
  ssn = db.Column(db.Integer, index=True, unique=True, nullable=False)
  email = db.Column(db.String(60), index=False, unique=True, nullable=False)
  address = db.Column(db.String(60), index=False, nullable=False)
  dep_name = db.Column(db.String(60), index=False, nullable=False)
  password = db.Column(db.String(60), index=False, nullable=False)
  entries = db.relationship('Time_Entry', backref='employee', lazy=True)

  def get_id(self):
    return (self.employee_id)

  def __repr__(self):
    return f"User('{self.employee_id}', '{self.email}')"


@login_manager.user_loader
def load_user(employee_id):
   return User.query.get(int(employee_id))  
  

class Time_Entry(db.Model):
  __tablename__ = 'Time_Entry'
  employee_id = db.Column(db.Integer, primary_key=True)
  time_in = db.Column(db.Time(), index=False, nullable=False)
  time_out = db.Column(db.Time(), index=False, nullable=False)
  request_id = db.Column(db.Integer, db.ForeignKey('User.employee_id'), nullable=False)

  def get_id(self):
    return (self.employee_id)

  def __repr__(self):
        return f"Time Elapsed for ('{self.employee_id}' is '{self.time_elapsed}')"



class Paycheck(db.Model):
  Paycheck_ID = db.Column(db.Integer,index=True, primary_key=True, nullable=False )
  Employee_ID = db.Column(db.Integer,nullable=False)
  Start_Date = db.Column(db.Date, index=False, nullable=False)
  End_date = db.Column(db.Date, index=False, nullable=False)
  TimeElapsed = db.Column(db.Float, index=False)
  HourlyWage = db.Column(db.Float, index=False)
  TotalPay = db.Column(db.Float, index=False)


  def get_paycheckid(self):
    return (self.Paycheck_ID)

  def get_employeeid(self):
    return (self.Employee_ID)

  def __repr__(self):
    return f"Time Elapsed from ('{self.Start_Date}'  to '{self.End_Date}'is '{self.TimeElapsed}'and total pay is '{self.TotalPay}')"



  
  
