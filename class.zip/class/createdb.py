import sqlite3

con = sqlite3.connect('beers.db')
con = sqlite3.connect('sales.db')

print("Database opened successfully")
con.execute("create table Beers (id INTEGER PRIMARY KEY AUTOINCREMENT, name CHAR(20), manf CHAR(20), available INTEGER) ")
print("Table created successfully")
con.execute("create table Sales (id INTEGER PRIMARY KEY AUTOINCREMENT, beername CHAR(20), quantity INTEGER ) ")
print("Table created successfully")
con.close()
